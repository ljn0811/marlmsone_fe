import React, {useState, useEffect} from "react";
import axios from "axios";
import Modal from "react-modal";
import Pagination from "../../components/common/Pagination";
import { useQueryParam } from "../../../hook/useQueryParam";




const Student = () => {

    const queryParam = useQueryParam();
    const searchLecId = queryParam.get('id');

    let pageSize = 5;
    let blockSize = 10;

    const [lecCurrentPage, setLecCurrentPage] = useState(1);
    const [lecStdCurrentPage, setLecStdCurrentPage] = useState(1);

    // 검색어 정보
    const [searchKey, setSearchKey] = useState('');
    const [searchLecInput, setSearchLecInput] = useState('');
    const [searchLecStdInput, setSearchLecStdInput] = useState('');
    
    // login id
    const [tutorId, setTutorId] = useState('');

    // 강의 목록
    const [lecList, setLecList] = useState([]);
    const [lecTotalCnt, setLecTotalCnt] = useState(0);

    // 수강생 목록
    const [lecStdList, setLecStdList] = useState([]);
    const [lecStdTotalCnt, setLecStdTotalCnt] = useState(0);

    const [lecStdListDisplay, setLecStdListDisplay] = useState(false);    
    const [lecDtlModalDisplay, setLecDtlModalDisplay] = useState(false);
    const [stdDtlModalDisplay, setStdDtlModalDisplay] = useState(false);

    // 강의 상세 정보
    const [lecName, setLecName] = useState('');
    const [maxPnum, setMaxPnum] = useState(0);
    const [tutorName, setTutorName] = useState('');
    const [lecrmName, setLecrmName] = useState('');
    const [processDay, setProcessDay] = useState(0);
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');

    // 수강생 상세 정보
    const [selLecId, setSelLecId] = useState(0);
    const [stdId, setStdId] = useState('');
    const [stdNumber, setStdNumber] = useState('');
    const [stdName, setStdName] = useState('');
    const [stdSex, setStdSex] = useState('');
    const [stdTel, setStdTel] = useState('');
    const [stdEmail, setStdEmail] = useState('');
    const [stdAddress, setStdAddress] = useState('');
    const [stdDetailList, setStdDetailList] = useState([]);
    


    useEffect(() => {
        searchLecList();
        setLecStdList(false);
    }, [searchLecId]);

    // 수강생 목록 조회
    const searchLecStdList = (lectureId, cpage) => {

        cpage = typeof cpage === 'object'? 1 : cpage || 1;
        
        setSelLecId(lectureId);
        setLecStdCurrentPage(cpage);
        setSearchLecStdInput("");
        setLecStdListDisplay(true);

		// var param = {
		// 	tutorId : tutorId,
		// 	lectureValue : lectureId,
		// 	currentPage : currentPage,
		// 	pageSize : pageSize,
		// 	searchKey: searchKey,
		// 	studentValue : studentValue
		// }
        // url: '/tut/LectureStudentList',

        let params = new URLSearchParams();

        params.append('tutorId', tutorId);
        params.append('lectureValue', lectureId);
        params.append('currentPage', cpage);
        params.append('pageSize', pageSize);
        params.append('searchKey', searchKey);
        params.append('studentValue', searchLecStdInput);

        axios.post("/tut/LectureStudentListjson.do", params)
            .then((res) => {
                // {"data":{"lectureStudentList":
                //          [{"lec_Id":1,"lec_name":null,
                //            "std_id":"123123 ","student_name":"123",
                //            "student_number":"26","student_tel":"123-1231-1234",
                //            "student_sex":"M","student_mail":"123@123",
                //            "student_addr":"123,123,123","join_date":"2021-05-06",
                //            "survey_yn":"y","approve_yn":"Y","startDate":null,"endDate":null}
                //          "pageSize":5,"lectureValue":"1","totalCount":5,"currentPage":1}

                console.log("searchLecStdList() result console : " + JSON.stringify(res));

                setLecStdTotalCnt(res.data.totalCount);
                setLecStdList(res.data.lectureStudentList);
            })
            .catch((err) => {
                console.log("searchLecStdList() result error : " + err.message);
                alert(err.message);
            });
    }

    // 수강생 정보 상세보기
    const searchLecStdDetail = (stdId) => {

        // var param = {
        //     tutorId : tutorId,
        //     studentId : studentId
        // }
        // url: '/tut/lectureStudentDetail',

        let params = new URLSearchParams();

        params.append('tutorId', tutorId);
        params.append('studentId', stdId);

        axios.post("/tut/lectureStudentDetail.do", params)
            .then((res) => {
                // {"data":{"detailTutorLecture":[{"lec_Id":1,"lec_name":"자바의이해",
                //                                 "std_id":"123123 ","student_name":"123",
                //                                 "student_number":"26","student_tel":"123-1231-1234",
                //                                 "student_sex":"M","student_mail":"123@123",
                //                                 "student_addr":"123,123,123","join_date":"2021-05-06",
                //                                 "survey_yn":"y","approve_yn":"Y",
                //                                 "startDate":"2024-03-05","endDate":"2024-06-15"},

                console.log("searchLecStdDetail() result console : " + JSON.stringify(res));
                
                setStdId(res.data.detailTutorLecture[0].std_id);
                setStdName(res.data.detailTutorLecture[0].student_name);
                setStdNumber(res.data.detailTutorLecture[0].student_number);
                setStdTel(res.data.detailTutorLecture[0].student_tel);                
                setStdSex(res.data.detailTutorLecture[0].student_sex === "M"? "남":"여");
                setStdEmail(res.data.detailTutorLecture[0].student_mail);
                setStdAddress(res.data.detailTutorLecture[0].student_addr);
                setStdDetailList(res.data.detailTutorLecture);

                setStdDtlModalDisplay(true);
            })
            .catch((err) => {
                console.log("searchLecStdDetail() result error : " + err.message);
                alert(err.message);
            });
    }

    // 수강신청 승인
    const approveLecStd = (stdId, lecId) => {
        // var param = {
        //     studentId : studentId,
        //     lectureId : lectureId
        // }
        // url: '/tut/lectureStudentApprove',

        let params = new URLSearchParams();

        params.append('studentId', stdId);
        params.append('lectureId', lecId);

        axios.post("/tut/lectureStudentApprove.do", params)
            .then((res) => {
                // {"data":true,"status":200,"statusText":"OK"
                console.log("approveLecStd() result console : " + JSON.stringify(res));

                if (res.data === true) {
                    alert("수강 승인이 완료되었습니다.");
                    searchLecStdList(lecId, lecStdCurrentPage);
                }
            })
            .catch((err) => {
                console.log("approveLecStd() result error : " + err.message);
                alert(err.message);
            });
    }

    // 수강신청 취소
    const cancelLecStd = (stdId, lecId) => {
        // var param = {
        //     studentId : studentId,
        //     lectureId : lectureId
        // }
        // url: '/tut/lectureStudentApprove',

        let params = new URLSearchParams();

        params.append('studentId', stdId);
        params.append('lectureId', lecId);

        axios.post("/tut/lectureStudentCancle.do", params)
            .then((res) => {
                // {"data":true,"status":200,"statusText":"OK"
                console.log("cancelLecStd() result console : " + JSON.stringify(res));

                if (res.data === true) {
                    alert("수강 취소가 완료되었습니다.");
                    searchLecStdList(lecId, lecStdCurrentPage);
                }
            })
            .catch((err) => {
                console.log("cancelLecStd() result error : " + err.message);
                alert(err.message);
            });
    }

    const stdDtlModalClose = () => {
        setStdDtlModalDisplay(false);
    }

    // 날짜를 yyyy-MM-dd 형식으로 포맷하는 함수
    function formatDate(dateString) {
        const date = new Date(dateString);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');

        return `${year}-${month}-${day}`;
    }

    const searchstyle = {
        fontsize: "15px",    
        fontweight: "bold",
    };

    const searchstylewidth = {
        height: "28px",
        width: "200px",    
    };

    const modalStyle = {
        content: {
          top: "50%",
          left: "50%",
          right: "auto",
          bottom: "auto",
          boxShdow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
          transform: "translate(-50%, -50%)",
        },
      };

    return (
        <div>
            {/* 수강생목록 조회 */}
            {lecStdListDisplay && (
                <div>
                    <p className="conTitle">
                        <span>수강생 목록</span>
                        <span className="fr">
                            <select id="searchKey" 
                                    className="form-control"
                                    style={searchstyle}
                                    onChange={(e) => {
                                        setSearchKey(e.target.value)
                                    }}>
                                <option value="all">전체</option>
                                <option value="studentName">이름</option>
                                <option value="studentId">아이디</option>
                                <option value="studentTel">전화번호</option>
                            </select>                    
                            <input type="text" 
                                className="form-control"
                                id="searchLecStdInput"
                                name="searchLecStdInput"
                                placeholder=""
                                style={searchstylewidth}
                                onChange={(e) => {
                                    setSearchLecStdInput(e.target.value)
                                }}
                            />
                            <button className="btn btn-primary"
                                id="searchbtn"
                                name="searchbtn"
                                onClick={(e) => {
                                    searchLecStdList(selLecId, lecStdCurrentPage);
                                }}
                            >
                                <span>검색</span>
                            </button>
                        </span>
                    </p>

                    <div>
                        <span>총 건수 : {lecStdTotalCnt} / 현재 페이지 번호 : {lecStdCurrentPage}</span>
                        <table className="col">
                            <colgroup>
                                <col width="15%"/>
                                <col width="15%"/>
                                <col width="20%"/>
                                <col width="20%"/>
                                <col width="15%"/>
                                <col width="15%"/>
                            </colgroup>
                            <thead>
                                <tr>
                                    <th>학번</th>
                                    <th>학생명(ID)</th>
                                    <th>휴대전화</th>
                                    <th>가입일자</th>
                                    <th>승인여부</th>
                                    <th>강의 승인</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    lecStdTotalCnt === 0 && (
                                        <tr>
                                            <td colSpan="6">데이터가 없습니다.</td>
                                        </tr>
                                    )
                                }
                                {/* 학생 목록 looping */}
                                {
                                    // {"data":{"lectureStudentList":
                                    //          [{"lec_Id":1,"lec_name":null,
                                    //            "std_id":"123123 ","student_name":"123",
                                    //            "student_number":"26","student_tel":"123-1231-1234",
                                    //            "student_sex":"M","student_mail":"123@123",
                                    //            "student_addr":"123,123,123","join_date":"2021-05-06",
                                    //            "survey_yn":"y","approve_yn":"Y","startDate":null,"endDate":null}
                                    //          "pageSize":5,"lectureValue":"1","totalCount":5,"currentPage":1}

                                    lecStdTotalCnt > 0 && lecStdList.map((item) => {
                                        return (
                                            <tr>
                                                <td>{item.student_number}</td>
                                                <td className="pointer-cursor" 
                                                    onClick={() => {
                                                        searchLecStdDetail(item.std_id)
                                                    }}>{item.student_name} ({item.std_id})</td>                                        
                                                <td>{item.student_tel}</td>
                                                <td>{formatDate(item.join_date)}</td>
                                                <td>{item.approve_yn}</td>
                                                <td>{
                                                    item.approve_yn === 'N'? 
                                                        <button className="btn btn-primary"
                                                                id="searchbtn"
                                                                name="searchbtn"
                                                                onClick={(e) => {
                                                                    approveLecStd(item.std_id, item.lec_Id)
                                                                }}>
                                                                <span>승인</span>
                                                        </button> :
                                                        <button className="btn btn-primary"
                                                                id="searchbtn"
                                                                name="searchbtn"
                                                                onClick={(e) => {
                                                                    cancelLecStd(item.std_id, item.lec_Id)
                                                                }}>
                                                                <span>취소</span>
                                                        </button>
                                                    }                                            
                                                </td>
                                            </tr>
                                        );
                                    })
                                }
                            </tbody>
                        </table>
                        {/* 학생목록 페이징 */}
                        {
                            lecStdTotalCnt > 0 && <Pagination currentPage={lecStdCurrentPage}
                                                        totalPage={lecStdTotalCnt}
                                                        pageSize={pageSize}
                                                        blockSize={blockSize}
                                                        onClick={searchLecStdList}/>
                        }
                    </div>
                </div>
             )} {/* End 수강생목록 조회 */}          
             
            {/* 수강생 상세정보 모달 */}
            <Modal style={modalStyle}
                isOpen={stdDtlModalDisplay}
                onRequestClose={stdDtlModalClose}>
                <div id="stdDtlForm">
                    <p className="conTitle">
                        <span>수강생 정보</span>
                    </p>
                    <table style={{ width: "550px", height: "200px" }}>
                        <colgroup>
                            <col width="15%"/>
                            <col width="35%"/>
                            <col width="15%"/>
                            <col width="35%"/>
                        </colgroup>
                        <tr>
                            <th>ID</th>
                            <td>{stdId}</td>
                            <th>학번</th>
                            <td>{stdNumber}</td>
                        </tr>
                        <tr>
                            <th>이름</th>
                            <td>{stdName}</td>
                            <th>성별</th>
                            <td>{stdSex}</td>
                        </tr>
                        <tr>
                            <th>전화번호</th>
                            <td>{stdTel}</td>
                            <th>이메일</th>
                            <td>{stdEmail}</td>
                        </tr>
                        <tr>
                            <th>주소</th>
                            <td colSpan="3">{stdAddress}</td>
                        </tr>                                          
                    </table>
                    <table className="col">
                        <colgroup>
                            <col width="15%"/>
                            <col width="25%"/>
                            <col width="60%"/>
                        </colgroup>
                        <thead>
                            <tr>
                                <th>과정ID</th>
                                <th>과정명</th>
                                <th>기간</th>
                            </tr>
                        </thead>
                        <tbody>
                            {/* 수강생의 수강 목록 looping */}
                            {
                                // {"data":{"detailTutorLecture":[{"lec_Id":1,"lec_name":"자바의이해",
                                                    // "std_id":"123123 ","student_name":"123",
                                                    // "student_number":"26","student_tel":"123-1231-1234",
                                                    // "student_sex":"M","student_mail":"123@123",
                                                    // "student_addr":"123,123,123","join_date":"2021-05-06",
                                                    // "survey_yn":"y","approve_yn":"Y",
                                                    // "startDate":"2024-03-05","endDate":"2024-06-15"},
                                stdDetailList.length > 0 && stdDetailList.map((item) => {
                                    return (
                                        <tr>
                                            <td>{item.lec_Id}</td>
                                            <td>{item.lec_name}</td>
                                            <td>{formatDate(item.startDate)} ~ {formatDate(item.endDate)}</td>
                                        </tr>
                                    );
                                })
                            }
                        </tbody>
                    </table>                                                      
                        
                    <div className="modal-button">
                        <button className="btn btn-primary mx-2" 
                                onClick={stdDtlModalClose}>확인</button>                    
                    </div>  
                </div>    
            </Modal>{/* End 수강생 상세정보 모달 */}
        </div>
    )    
}

export default Student